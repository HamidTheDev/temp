import { getDesignInteraction } from "@canva/design-interaction";
import * as React from "react";
import styles from "styles/components.css";

export const App = () => {
  const designInteraction = getDesignInteraction();

  const onClick = () => {
    designInteraction.addNativeElement({
      type: "TEXT",
      children: ["Hello world!"],
    });
  };

  return (
    <div className={styles.scrollContainer}>
      <p className={styles.paragraph}>
        To make changes to this app, edit the
        <code className={styles.code}>src/app.tsx</code> file, then close and
        reopen the app in the editor to preview the changes.
      </p>
      <button className={styles.button} onClick={onClick}>
        Do something cool
      </button>
    </div>
  );
};
