export function getExport() {
  if (window.canva && window.canva.export) {
    return window.canva.export;
  }

  throw new Error('[INTERNAL_ERROR]: Could not retrieve the preview Export SDK client');
}
