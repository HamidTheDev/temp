/**
 * @beta
 * An API for exporting the user's design as one or more static files.
 */
export declare interface Export {

    /**
     * Exports the user's design as one or more static files.
     * @param request - The request object containing configurations of the design export.
     */
    requestExport(request: ExportRequest): Promise<ExportResponse>;
}

/**
 * @beta
 * Export aborted response
 *
 * @remarks
 * An export flow is considered aborted when a user closes

 * the export options menu.
 */
export declare type ExportAborted = {
    /**
     * The status of the export flow when the user has aborted the export menu.
     */
    status: 'ABORTED';
};

/**
 * @beta
 * The exported file.
 */
export declare type ExportBlob = {
    /**
     * The URL of the exported design.
     *
     * @remarks
     * If the user's design contains multiple pages but is exported in a format that doesn't support multiple pages, the URL will point to a ZIP file that contains each page as a separate file.
     *
     * For example:
     *
     * - If a single-page design is exported as a JPG, the URL will point to a JPG file
     * - If a multi-page design is exported as a JPG, the URL will point to a ZIP file that contains a separate JPG file for each page
     * - If a multi-page design is exported as a PDF, the URL will point to a PDF file that contains all of the pages
     *
     * The following file types support multiple pages:
     *
     * - `"GIF"`
     * - `"PDF_STANDARD"`
     * - `"PPTX"`
     * - `"VIDEO"`
     *
     * The following file types do not support multiple pages:
     *
     * - `"JPG"`
     * - `"PNG"`
     * - `"SVG"`
     */
    url: string;
};

/**
 * @beta
 * Export completed response
 */
export declare type ExportCompleted = {
    /**
     * The status of the export flow when the user has submitted the export menu.
     */
    status: 'COMPLETED';
    /**
     * The exported files.
     *
     * @remarks
     * This array only contains one element. This is because, if a multi-page design is exported as multiple files, the files are exported in a ZIP file. In the future, there'll be an option for each file to be a separate element in the array.
     */
    exportBlobs: ExportBlob[];
};

/**
 * @beta
 * The types of files that Canva supports for exported designs.
 */
export declare type ExportFileType = 'PNG' | 'JPG' | 'PDF_STANDARD' | 'VIDEO' | 'GIF' | 'PPTX' | 'SVG';

/**
 * @beta
 * The options for configuring the export of a design.
 */
export declare type ExportRequest = {
    /**
     * The types of files the user can export their design as.
     *
     * @remarks
     * You must provide at least one file type.
     */
    acceptedFileTypes: ExportFileType[];
};

/**
 * @beta
 * The response of an export request.
 */
export declare type ExportResponse = ExportCompleted | ExportAborted;

/**
 * @beta
 * Get the export client
 */
export declare function getExport(): Export;

export { }
