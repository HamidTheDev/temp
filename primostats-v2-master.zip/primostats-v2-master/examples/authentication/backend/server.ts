require("dotenv").config();
import * as express from "express";
import * as cors from "cors";
import { getTokenFromQueryString } from "../../../utils/backend/jwt_middleware/jwt_middleware";
import { createBaseServer } from "../../../utils/backend/base_backend/create";
import { createJwtMiddleware } from "../../../utils/backend/jwt_middleware";
import { Client } from 'pg';
import axios from "axios";

const wpBaseUrl = 'https://primostats.com/wp-json/api/v2';
let client: Client | null = null;
const connectDb = () => {
  // if (client != null) return client;
  const _client = new Client({
    user: process.env.PGUSER,
    host: process.env.PGHOST,
    database: process.env.PGDATABASE,
    password: process.env.PGPASSWORD,
    port: +process.env.PGPORT!,
  });
  client = _client;
  return client;
};

/** Connect to database and send a request */
export const dbQuery = async (query) => {
  const _client = connectDb();
  if (_client) {
    _client.connect();
    const data = await _client.query(query);
    await _client.end();
    return data;
  }
};

/**
 * This file contains routes for demonstrating the authentication demo. You can
 * find the frontend of this demo in app/src/examples/authentication.tsx.
 */

type Data = {
  users: string[];
};

async function main() {
  // add your CANVA_APP_ID to the .env file at the root level
  const APP_ID = process.env.CANVA_APP_ID;
  if (!APP_ID) {
    throw new Error(
      `The CANVA_APP_ID environment variable is undefined. Set the variable in the project's .env file.`
    );
  }

  const router = express.Router();
  router.use(cors());
  router.get(
    "/redirect-url",
    createJwtMiddleware(APP_ID, getTokenFromQueryString),
    async (req, res) => {
      // Get the user's ID from the query parameters
      const { user } = req.query;
      const { brandId } = req.canva;
      if (typeof user !== "string") {
        console.error(
          `user field in query parameters: expected 'string' but found '${typeof user}'`
        );
        res.status(400).send({});
        return;
      }

      // Get the user's ID from the query parameters
      const { userWpId } = req.query;
      if (!userWpId) {
        res.status(404).send('user wp ID not found');
        return;
      }

      // Load the database
      const savedUser = await dbQuery(`SELECT * FROM canva_users WHERE user_canva_id = '${user}' AND user_wp_id = '${userWpId}' AND canva_team_id = '${brandId}'`);

      if (!savedUser?.rows[0]) { // if user not found, add them
        await dbQuery(
          `INSERT INTO canva_users(user_wp_id, user_canva_id, canva_team_id) VALUES(${userWpId}, '${user}', '${brandId}') RETURNING *`
        );
      }

      // Create query parameters for redirecting back to Canva
      const params = new URLSearchParams({
        success: "true",
        state: req?.query?.state?.toString() || "",
      });

      // Redirect the user back to Canva
      res.redirect(302, `https://canva.com/apps/configured?${params}`);
    }
  );

  const jwtMiddleware = createJwtMiddleware(APP_ID);
  router.post("/configuration/delete", jwtMiddleware, async (req, res) => {
    // Get the user's ID from the request body
    const { user } = req.body;

    // Load the database
    await dbQuery(`DELETE FROM canva_users WHERE user_canva_id = '${user}'`);

    // Confirm that the user was removed
    res.send({
      type: "SUCCESS",
    });
  });

  router.use("/api", jwtMiddleware);
  router.post("/api/authentication/status", async (req, res) => {
    // Load the database
    const userExists = await dbQuery(`SELECT * FROM canva_users WHERE user_canva_id = '${req.canva.userId}' AND canva_team_id = '${req.canva.brandId}'`);

    // Check if the user is authenticated
    const isAuthenticated = !!userExists?.rows[0];

    // Return the authentication status
    res.send({
      isAuthenticated,
    });
  });

  router.post('/api/fav-stats', async (req, res) => {
    const userCanvaId = req.canva.userId;
    console.log('user canva id', userCanvaId);
    const userResponse = await dbQuery(`SELECT * FROM canva_users WHERE user_canva_id = '${userCanvaId}'`);
    const user = userResponse.rows[0];
    console.log('user here', user);
    const response = await axios.get(`${wpBaseUrl}/fav-stats/byUser/${user.user_wp_id}`);
    res.send(response.data);
  });

  router.post('/api/logout', async (req, res) => {
    const userCanvaId = req.canva.userId;
    console.log('user canva id', userCanvaId);
    const setUser = await dbQuery(
      `DELETE FROM canva_users WHERE user_canva_id = '${userCanvaId}' RETURNING *`
    );
    res.send(setUser.data);
  });

  const server = createBaseServer(router);
  server.start(process.env.CANVA_BACKEND_PORT);
}

main();
