import { getAuthentication } from "@canva/authentication";
import type { Authentication } from "@canva/authentication";
import React, { useEffect, useState } from "react";
import styles from "styles/components.css";
import { tokens } from "styles/tokens";
import clsx from "clsx";
import { DraggableText } from "components/draggable_text";

type State = "authenticated" | "not_authenticated" | "checking" | "error";

/**
 * This endpoint is defined in the ./backend/server.ts file. You need to
 * register the endpoint in the Developer Portal before sending requests.
 *
 * BACKEND_HOST is configured in the root .env file, for more information,
 * refer to the README.md.
 */
const AUTHENTICATION_CHECK_URL = `${BACKEND_HOST}/api/authentication/status`;

const checkAuthenticationStatus = async (
  auth: Authentication
): Promise<State> => {
  /**
   * Send a request to an endpoint that checks if the user is authenticated. This
   * is a (very) rudimentary implementation.
   *
   * Note: You must register the provided endpoint via the Developer Portal.
   */
  try {
    const token = await auth.getCanvaUserToken();
    const res = await fetch(AUTHENTICATION_CHECK_URL, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      method: "POST",
    });
    const body = await res.json();

    if (body?.isAuthenticated) {
      return "authenticated";
    } else {
      return "not_authenticated";
    }
  } catch (error) {
    console.error(error);
    return "error";
  }
};

export const App = () => {
  const auth = getAuthentication();
  const [state, setState] = useState<State>("checking");
  const [loadingText, setLoadingText] = useState<boolean>(false);
  const [error, setError] = useState("");
  const [openStat, setOpenStat] = useState(0); // to highlight active stat
  const [favStats, setFavStats] = useState<any>([]);
  const [loading, setLoading] = useState(false); // used in auth button
  const [stats, setStats] = useState<any>([]);
  const [selectedStat, setSelectedStat] = useState<string>("");

  React.useEffect(() => {
    checkAuthenticationStatus(auth).then((status) => {
      setState(status);
    });
  }, []);

  useEffect(() => {
    if (state === "authenticated") {
      handleRefresh();
    }
  }, [state]);

  const getFavStats = async () => {
    setLoadingText(true);
    try {
      const token = await auth.getCanvaUserToken();
      const res = await fetch(`${BACKEND_HOST}/api/fav-stats`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const body = await res.json();
      if (!body || body.length === 0) {
        setError("You have no favorite stats.");
        setLoadingText(false);
        setFavStats([]);
        return;
      }
      setLoadingText(false);
      return body;
    } catch (e) {
      setError(
        "Something wrong happened, please try again or refresh the page."
      );
      console.error("Primostats error: ", e);
    }
  };

  const handleRefresh = async () => {
    setLoadingText(true);
    try {
      const favStats = await getFavStats();
      if (favStats && favStats.length) {
        showFavStats(favStats);
        setError("");
      }
    } catch (e) {
      setError(
        "Something wrong happened, please try again or refresh the page."
      );
      console.error("Primostats error: ", e);
    }
  };

  const showFavStats = (_favStats) => {
    setLoading(false);
    setStats(_favStats);
    if (_favStats?.length) {
      setFavStats(_favStats);
      setSelectedStat(_favStats?.[0].id);
    }
  };

  const startAuthenticationFlow = async () => {
    // Start the authentication flow
    try {
      const response = await auth.requestAuthentication();
      switch (response.status) {
        case "COMPLETED":
          setState("authenticated");
          console.log("authenticated");
          break;
        case "ABORTED":
          console.warn("Authentication aborted by user.");
          setState("not_authenticated");
          break;
        case "DENIED":
          console.warn("Authentication denied by user", response.details);
          setState("not_authenticated");
          break;
      }
    } catch (e) {
      console.error(e);
      setState("error");
    }
  };

  const handleLogout = async () => {
    const token = await auth.getCanvaUserToken();
    await fetch(`${BACKEND_HOST}/api/logout`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    setState("not_authenticated");
    setFavStats([]);
  };

  if (state === "error") {
    return (
      <div className={styles.scrollContainer}>
        <div>
          <strong>Something went wrong.</strong> Please try again.
        </div>
      </div>
    );
  }

  return (
    <div className={styles.scrollContainer}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <div>
          <h4 className={clsx(styles.subtitle)} style={{ marginTop: 0 }}>
            Create relevant designs
          </h4>
          <p className={clsx(styles.paragraph, styles.secondary)}>
            Add your favourite stats into your designs.
          </p>
        </div>
        {/* <div>
          {state === "authenticated" && (
            <button
              className={clsx(
                styles.button,
                styles.primary,
                loadingText ? styles.loading : null
              )}
              disabled={loadingText}
              onClick={() => handleRefresh()}
            >
              Refresh
            </button>
          )}
        </div> */}
      </div>
      {state !== "authenticated" && (
        <button
          className={styles.button}
          onClick={startAuthenticationFlow}
          disabled={state === "checking"}
        >
          Log In
        </button>
      )}
      {error.length > 0 && <div style={{ color: "#ff4757" }}>{error}</div>}
      {loadingText && error.length === 0 && (
        <div className="loading-element">
          <p>Loading Stats...</p>
        </div>
      )}

      {!loadingText && favStats.length > 0 && (
        <>
          <p
            className={styles.label}
            style={{
              borderBottom: "solid 2px",
              borderColor: tokens.colorPrimary,
              paddingBottom: 10,
              paddingLeft: 10,
              paddingRight: 10,
              display: 'inline-block'
            }}
          >
            All Favorites
          </p>
          <div style={{ marginBottom: 60 }}>
            {favStats.map((_stat, i) => (
              <DraggableText
                className={clsx(styles.paragraph, styles.secondary)}
              >
                <div
                  className={openStat === i ? "stat-item open" : "stat-item"}
                  key={i}
                  onClick={() => {
                    setSelectedStat(_stat.id);
                    setOpenStat(i);
                  }}
                  style={{
                    borderColor: tokens.colorSecondaryDisabled,
                    borderStyle: "solid",
                    borderWidth: 2,
                    borderRadius: 5,
                    padding: 10,
                    marginBottom: tokens.smallSpace,
                  }}
                >
                  <div className="heading">
                    <p>{_stat.statistic}</p>
                  </div>
                  <div
                    className="info"
                    style={{ marginTop: tokens.smallSpace }}
                  >
                    <p>
                      <small>Publication Title: {_stat.publication}</small>
                    </p>
                    <p>
                      <small>Year: {_stat.year}</small>
                    </p>
                    <p>
                      <small>Source: {_stat.source}</small>
                    </p>
                    <p>
                      <small>Source Link: {_stat.source_url}</small>
                    </p>
                  </div>
                </div>
              </DraggableText>
            ))}
          </div>
        </>
      )}

      {state === "authenticated" && (
        <div
          className="fixed-button"
          style={{
            background: "rgb(37, 38, 39)",
            position: "fixed",
            bottom: 0,
            left: 0,
            right: 0,
            paddingBottom: 10,
            paddingTop: 10,
            display: "flex",
            justifyContent: "flex-start",
          }}
        >
          <button
            className={clsx(styles.button, styles.secondary)}
            style={{ width: "auto" }}
            onClick={() => handleLogout()}
          >
            Log Out
          </button>
        </div>
      )}
    </div>
  );
};
