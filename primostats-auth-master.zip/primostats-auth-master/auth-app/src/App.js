import { useSearchParams } from 'react-router-dom';
import { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [searchParams] = useSearchParams();
  const userCanvaId = searchParams.get("user");
  const state = searchParams.get("state");
  const signatures = searchParams.get("signatures");
  const user = searchParams.get("user");
  const brand = searchParams.get("brand");
  const extensions = searchParams.get("extensions");
  const time = searchParams.get("time");

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [disabled, setDisabled] = useState(false);

  const handleLogin = async () => {
    setDisabled(true);
    const response = await axios.post('https://primostats.com/wp-json/api/v2/login', {
      email,
      password
    });
    const data = response.data;
    if (data.status === 200) {
      const userWpId = data.data.id;
      // TODO: send request to nodejs backend to check if userCanvaId is connected to wpId
      window.location.href = `https://canva-be.primostats.com/redirect-url?user=${user}&brand=${brand}&extensions=${extensions}&userWpId=${userWpId}&userCanvaId=${userCanvaId}&state=${state}&signatures=${signatures}&time=${time}`;
      return;
    } else {
      console.log('login credentials incorrect.');
      setDisabled(false);
    }
  };

  return (
    <div className="App">
      <div className="app-form">
        <div style={{display: 'flex', justifyContent: 'center'}}>
          <a href="https://primostats.com" target="_blank" rel="noreferrer"><img alt="Primostats logo" src="logo.png" width="200" /></a>
        </div>
        <h1>Log In</h1>
        <div>
          <label htmlFor='email'>Email Address</label>
          <input type="text" id="email" onChange={v => setEmail(v.target.value)} />
        </div>
        <div>
          <label htmlFor='password'>Password</label>
          <input type="password" id="password" onChange={v => setPassword(v.target.value)} />
        </div>
        <button disabled={disabled} onClick={handleLogin}>{disabled ? 'Loading...' : 'Log In'}</button>
      </div>
    </div>
  );
}

export default App;
