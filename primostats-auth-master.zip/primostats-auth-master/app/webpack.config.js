const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const TerserPlugin = require("terser-webpack-plugin");
const CssMinimizerPlugin = require("css-minimizer-webpack-plugin");

module.exports = (env, argv) => {
  const mode = argv.mode;
  const environment = env.environment;

  return {
    context: path.resolve(__dirname, './'),
    entry: {
      app: path.join(__dirname, 'src', 'index.tsx'),
    },
    target: 'web',
    resolve: {
      alias: {
        react: require.resolve('react'),
      },
      extensions: ['.ts', '.tsx', '.js', '.css', '.svg'],
    },
    devServer: {
      webSocketServer: false,
      server: 'https',
    },
    module: {
      rules: [
        {
          test: /\.tsx?$/,
          exclude: '/node_modules/',
          use: [
            {
              loader: 'ts-loader',
              options: {
                transpileOnly: mode === 'production',
              },
            },
          ],
        },
        {
          test: /\.css$/,
          include: [path.resolve(__dirname, 'src')],
          exclude: '/node_modules/',
          use: [
            'style-loader',
            'css-modules-typescript-loader',
            {
              loader: 'css-loader',
              options: {
                modules: true,
              },
            },
          ],
        },
        {
          test: /\.css$/,
          exclude: [path.resolve(__dirname, 'src')],
          use: [
            'style-loader',
            'css-loader'
          ]
        },
        {
          test: /\.(png|jpg|jpeg)$/i,
          type: 'asset/inline',
        },
        {
          test: /\.svg$/,
          oneOf: [
            {
              issuer: /\.[jt]sx?$/,
              resourceQuery: /react/, // *.svg?react
              use: ['@svgr/webpack', 'url-loader'],
            },
            {
              type: 'asset/resource',
              parser: {
                dataUrlCondition: {
                  maxSize: 200,
                },
              },
            },
          ],
        },
      ],
    },
    optimization: {
      minimizer: [
        new TerserPlugin(),
        new CssMinimizerPlugin(),
      ],
    },
    output: {
      filename: `[name].js`,
      path: path.resolve(__dirname, 'dist'),
      clean: true,
    },
    devtool: mode === 'development' ? 'source-map' : undefined,
    plugins: [
      new HtmlWebpackPlugin({
        template: path.join(__dirname, 'src', 'index.html'),
      }),
      new MiniCssExtractPlugin({
        filename: "[name].[contenthash].css",
      }),
    ],
  };
};
