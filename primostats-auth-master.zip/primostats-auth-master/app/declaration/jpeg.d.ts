declare module '*.jpg' {
  const content: string;
  // eslint-disable-next-line import/no-default-export
  export default content;
}

declare module '*.jpeg' {
  const content: string;
  // eslint-disable-next-line import/no-default-export
  export default content;
}
