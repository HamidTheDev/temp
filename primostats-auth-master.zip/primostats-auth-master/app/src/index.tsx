import * as React from 'react';
import * as ReactDOM from 'react-dom';
import "@canva/ui/build/lib/main.css"
import { Theme } from '@canva/ui';

/**
 * We've provided a number of examples in the ./examples directory. To import
 * any of them, simply replace "./app" with the path of the example.
 */
import { App } from './app';

const ThemedApp = () => (
  <>
    <Theme />
    <App />
  </>
);

ReactDOM.render(
  <ThemedApp />,
  document.getElementById('root'),
);
