import React from "react";
import type {
  AppElementData,
  DesignInteraction,
} from "@canva/design-interaction";
import { initDesignInteraction } from "@canva/design-interaction";
import type { Authentication } from "@canva/authentication";
import { initAuthentication } from "@canva/authentication";
import type {
  DragAndDrop,
} from "@canva/dnd";
import {
  initDragAndDrop,
} from "@canva/dnd";
import { Fetch, initFetch } from "@canva/fetch";


let designInteraction: Promise<DesignInteraction<any>> | undefined;
export function useDesignInteraction<
  T extends AppElementData
>(): DesignInteraction<T> | undefined {
  const [api, setApi] = React.useState<DesignInteraction<T> | undefined>();

  const init = async () => {
    if (!designInteraction) {
      designInteraction = initDesignInteraction<T>();
    }
    setApi(await designInteraction);
  };

  React.useEffect(() => {
    init();
  }, []);

  return api;
}

let fetch: Promise<Fetch> | undefined;
export function useFetch(): Fetch | undefined {
  const [api, setApi] = React.useState<Fetch | undefined>(undefined);

  const init = async () => {
    if (!fetch) {
      fetch = initFetch();
    }
    setApi(await fetch);
  };

  React.useEffect(() => {
    init();
  }, []);

  return api;
}

let dragAndDrop: Promise<DragAndDrop> | undefined;
export function useDragAndDrop(): DragAndDrop | undefined {
  const [api, setApi] = React.useState<DragAndDrop | undefined>(undefined);

  const init = async () => {
    if (!dragAndDrop) {
      dragAndDrop = initDragAndDrop();
    }
    setApi(await dragAndDrop);
  };

  React.useEffect(() => {
    init();
  }, []);

  return api;
}


let authentication: Promise<Authentication> | undefined;
export function useAuthentication(): Authentication | undefined {
  const [api, setApi] = React.useState<Authentication | undefined>(undefined);

  const init = async () => {
    if (!authentication) {
      authentication = initAuthentication();
    }
    setApi(await authentication);
  };

  React.useEffect(() => {
    init();
  }, []);

  return api;
}
