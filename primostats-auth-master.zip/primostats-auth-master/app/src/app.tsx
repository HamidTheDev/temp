import { NativeElementType } from "@canva/design-interaction";
import { Button, Rows, Spacer, Text, Title } from "@canva/ui";
import React, { useEffect, useState } from "react";
import { useAuthentication, useDesignInteraction, useDragAndDrop, useFetch } from "./hooks";


type State = "authenticated" | "not_authenticated" | "checking";/**
* This endpoint is defined in the backend/src/authentication.ts file. You need to
* register the endpoint in the Developer Portal before sending requests.
*/
const AUTHENTICATION_CHECK_ENDPOINT = "/authentication/check";

export const App = () => {
  const auth = useAuthentication();
  const fetch = useFetch();
  const designInteraction = useDesignInteraction();

  const [loading, setLoading] = useState(false); // used in auth button
  const [error, setError] = useState('');
  const [openStat, setOpenStat] = useState(0); // to highlight active stat

  const [stats, setStats] = useState<any>([]);
  const [favStats, setFavStats] = useState<any>([]);
  const [selectedStat, setSelectedStat] = useState<string>('');
  const [loadingText, setLoadingText] = useState<boolean>(false);
  const [state, setState] = React.useState<State>("checking");
  const [authenticatedCanvaId, setAuthenticatedCanvaId] = useState<string>('');

  useEffect(() => {
    console.log('init...')
    if (!fetch) return;

    try {
      fetch?.post({ endpoint: AUTHENTICATION_CHECK_ENDPOINT }).then((response) => {
        console.log('inside fetch request')
        if (response.body?.isAuthenticated) {
          setState("authenticated");
        } else {
          setState("not_authenticated");
        }
      });
    } catch(e) {
      setError('Something wrong happened, please try again or refresh the page.');
      console.error('Primostats error: ', e);
    }

    if (state === 'authenticated') {
      console.log('authenticated here')
      handleRefresh();
    }
  }, [fetch, state]);

  const getFavStats = async () => {
    setLoadingText(true);
    console.log('getting fav stats...')
    try {
      const favStats = await fetch?.post({ endpoint: '/fav-stats' });
      console.log('getting fav stats responded: ', favStats?.body);
      if (!favStats?.body || favStats?.body.length === 0) {
        setError('You have no favorite stats.');
        setLoading(false);
        setLoadingText(false);
        setFavStats([]);
        return;
      }
      setLoadingText(false);
      return favStats;
    } catch(e) {
      setError('Something wrong happened, please try again or refresh the page.');
      console.error('Primostats error: ', e);
    }
  };

  const showFavStats = (_favStats) => {
    setLoading(false);
    setStats(_favStats);
    console.log('fav stats from method', _favStats, typeof _favStats);
    if (_favStats?.length) {
      setFavStats(_favStats);
      setSelectedStat(_favStats?.[0].id);
    }
  };

  const logout = async () => {
    setLoading(true);
    try {
      const response = await fetch?.post({ endpoint: '/logout' });
      console.log('logged out...', response?.body);
      setFavStats([]);
      setLoading(false);
      setAuthenticatedCanvaId('');
      setError('');
      setState('not_authenticated');
    } catch(e) {
      setError('Something wrong happened, please try again or refresh the page.');
      console.error('Primostats error: ', e);
    }
  };

  const handleRefresh = async () => {
    setLoadingText(true);
    console.log('fav stats here...');
    try {
      const favStats = await getFavStats();
      console.log('fav stats:', favStats?.body)
      if (favStats?.body && favStats?.body.length) {
        showFavStats(favStats?.body);
        setError('');
      }
    } catch(e) {
      setError('Something wrong happened, please try again or refresh the page.');
      console.error('Primostats error: ', e);
    }
  }

  const startAuthenticationFlow = async () => {
    try {
      // Start the authentication flow
      const result = await auth?.authenticate();
  
      // Handle the result of the authentication flow
      if (result?.type === "authenticated") {
        setState("authenticated");
      }
    } catch(e) {
      setError('Something wrong happened, please try again or refresh the page.');
      console.error('Primostats error: ', e);
    }
  };

  return (
    <>
      <Spacer direction="vertical" size="large" />
      <Rows spacing="small">
        <div className="page-head">
          <Title>PrimoStats</Title>
          {state === 'authenticated' && 
          <div style={{display: 'flex'}}>
            <a 
              className="logout-btn"
              style={{ marginRight: 5, background: 'rgb(46, 140, 255)' }}
              onClick={() => handleRefresh()}>
              <Text size="micro">Refresh</Text>
            </a>
            <a className="logout-btn" onClick={() => logout()}><Text size="micro">Logout</Text></a>
          </div>
          }
        </div>
        <div style={{marginTop: '50px', paddingTop: '10px'}}>
        {state !== 'authenticated' && <AuthenticationButton state={state} onClick={startAuthenticationFlow} />}

        {error.length > 0 && <Text><div style={{color: '#ff4757'}}>{error}</div></Text>}

        {(loadingText && error.length === 0) && <div className="loading-element"><Text>Loading Stats...</Text></div>}

        {(!loadingText && favStats.length > 0) && 
        <>
          <Title size="small">Favorite Stats</Title>
          <div style={{marginBottom: 60, marginTop: 20}}>
            {favStats.map((_stat, i) => <>
              <div 
                className={openStat === i ? 'stat-item open' : 'stat-item'} 
                key={i} 
                onClick={() => {
                  setSelectedStat(_stat.id)
                  setOpenStat(i);
                }}>
                <div className="heading">
                  <Text>{_stat.statistic}</Text>
                </div>
                <div className="info">
                  <Text size="micro">Year: {_stat.year}</Text>
                  <Text size="micro">Publication Title: {_stat.publication}</Text>
                  <Text size="micro">Source: {_stat.source}</Text>
                  <Text size="micro">Source Link: {_stat.source_url}</Text>
                </div>
              </div>
            </>)}
          </div>
          <div className="fixed-button" style={{
              background: 'rgb(37, 38, 39)',
              position: 'fixed',
              bottom: 0,
              left: 0,
              right: 0,
              paddingBottom: 10,
              paddingTop: 10,
            }}>
            <Button
              onClick={() => {
                const currentStat = stats.find(s => s.id === selectedStat);
                designInteraction?.addNativeElement({
                  type: NativeElementType.TEXT,
                  children: [
                    currentStat.statistic
                    + '\n\nYear: ' + currentStat.year
                    + '\n\nPublication Title: ' + currentStat.publication
                    + '\n\nSource: ' + currentStat.source
                    + '\n\nSource Link: ' + currentStat.source_url
                  ],
                  fontSize: 100,
                });
              }}>
              Add to Design
            </Button>
          </div>
        </>}
        {authenticatedCanvaId.length > 0 && <Button onClick={() => handleRefresh()} disabled={loading}>Refresh Stats</Button>}
        </div>
      </Rows>
    </>
  );
};

const AuthenticationButton = ({
  state,
  onClick,
}: {
  state: State;
  onClick: () => void;
}) => {
  const disabled = state === "checking" || state === "authenticated";
  const loading = state === "checking";
  return (
    <Button onClick={onClick} disabled={disabled} loading={loading}>
      Authenticate
    </Button>
  );
};
