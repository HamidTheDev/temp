import type { DraggableElementData } from '@canva/dnd';
import * as React from 'react';
import { useDragAndDrop } from './hooks';

export const DraggableImage = (
    props: React.ImgHTMLAttributes<HTMLImageElement> & {
      dragData?: Partial<DraggableElementData['dragData']>,
    },
) => {
  const dragAndDrop = useDragAndDrop();
  const [img, setImg] = React.useState<HTMLImageElement | null>();
  const [isDragging, setIsDragging] = React.useState(false);
  const [canDrag, setCanDrag] = React.useState(false);
  const { dragData, ...imgProps } = props;
  const opacity = isDragging ? 0 : (props.style?.opacity || 1);

  React.useEffect(() => {
    if (!img) {
      return;
    }

    try {
      dragAndDrop?.makeDraggable({
        node: img,
        dragData: dragData,
        onDragEnd: () => setIsDragging(false),
        onDragStart: () => setIsDragging(true),
      });
      setCanDrag(true);
    } catch (e) {
      console.error(e);
    }
  }, [img, dragAndDrop]);

  return <img {...imgProps} draggable={canDrag} style={{ cursor: 'pointer', ...props.style, opacity }} ref={setImg}/>;

};
