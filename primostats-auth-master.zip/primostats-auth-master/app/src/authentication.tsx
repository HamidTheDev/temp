import { Button, Spacer, Rows, Title, Text } from "@canva/ui";
import { useAuthentication, useFetch } from "./hooks";
import React from "react";

type State = "authenticated" | "not_authenticated" | "checking";

/**
 * This endpoint is defined in the backend/src/authentication.ts file. You need to
 * register the endpoint in the Developer Portal before sending requests.
 */
const AUTHENTICATION_CHECK_ENDPOINT = "/authentication/check";

export const App = () => {
  const auth = useAuthentication();
  const fetch = useFetch();

  // Keep track of the user's authentication status.
  const [state, setState] = React.useState<State>("checking");

  /**
   * Use the Fetch capability to check if the current user is authenticated. Canva
   * includes the ID of the user in the headers of the request.
   */
  React.useEffect(() => {
    /**
     * Send a request to an endpoint that checks if the user is authenticated. This
     * is a (very) rudimentary implementation.
     *
     * Note: You must register the provided endpoint via the Developer Portal.
     */
    fetch?.post({ endpoint: AUTHENTICATION_CHECK_ENDPOINT }).then((response) => {
      if (response.body?.isAuthenticated) {
        setState("authenticated");
      } else {
        setState("not_authenticated");
      }
    });
  }, [fetch]);

  const startAuthenticationFlow = async () => {
    // Start the authentication flow
    const result = await auth?.authenticate();

    // Handle the result of the authentication flow
    if (result?.type === "authenticated") {
      setState("authenticated");
    }
  };

  return (
    <>
      <Spacer direction="vertical" size="large" />
      <Rows spacing="small">
        <Title>Authentication demo</Title>
        <Text>
          This example demonstrates how apps can allow users to authenticate
          with the app via a third-party platform.
        </Text>
        <Text>
          <strong>Note:</strong> The username is "user" and the password is
          "password".
        </Text>
        <Text>{createAuthenticationMessage(state)}</Text>
        <AuthenticationButton state={state} onClick={startAuthenticationFlow} />
      </Rows>
    </>
  );
};

const createAuthenticationMessage = (state: State) => {
  switch (state) {
    case "checking":
      return "Checking authentication status...";
    case "authenticated":
      return "You are authenticated!";
    case "not_authenticated":
      return "You are not authenticated.";
  }
};

const AuthenticationButton = ({
  state,
  onClick,
}: {
  state: State;
  onClick: () => void;
}) => {
  const disabled = state === "checking" || state === "authenticated";
  const loading = state === "checking";
  return (
    <Button onClick={onClick} disabled={disabled} loading={loading}>
      Authenticate
    </Button>
  );
};
