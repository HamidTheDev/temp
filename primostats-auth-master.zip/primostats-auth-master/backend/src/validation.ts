
import crypto from 'crypto';

export const isValidPostRequest = (secret, request) => {
  // Verify the timestamp
  const sentAtSeconds = request.header("X-Canva-Timestamp");
  const receivedAtSeconds = new Date().getTime() / 1000;

  if (!isValidTimestamp(sentAtSeconds, receivedAtSeconds)) {
    console.log('timestamp invalid', sentAtSeconds, receivedAtSeconds);
    return false;
  }

  // Construct the message
  const version = "v1";
  // const timestamp = request.header("x-canva-timestamp");
  const path = getPathForSignatureVerification(request.path);
  const body = request.rawBody;
  const message = `${version}:${request.headers}:${path}:${body}`;

  // Calculate a signature
  const signature = calculateSignature(secret, message);

  // Reject requests with invalid signatures
  if (!request.header("x-canva-signatures").includes(signature)) {
    console.log('signature invalid', signature, request.header('x-canva-signatures'));
    return false;
  }

  return true;
};

export const isValidGetRequest = (secret, request) => {
  console.log('### validating get request...');
  // Verify the timestamp
  const sentAtSeconds = request.query.time;
  const receivedAtSeconds = new Date().getTime() / 1000;

  if (!isValidTimestamp(sentAtSeconds, receivedAtSeconds)) {
    console.log('get timestamp', sentAtSeconds, receivedAtSeconds);
    console.log('get timestamp invalid');
    return false;
  }

  // Construct the message
  const version = "v1";
  const { time, user, brand, extensions, state } = request.query;
  const message = `${version}:${time}:${user}:${brand}:${extensions}:${state}`;
  console.log('message', message);

  // Calculate a signature
  const signature = calculateSignature(secret, message);

  // Reject requests with invalid signatures
  console.log('get signatures:', request.query.signatures, signature);
  if (!request.query.signatures.includes(signature)) {
    console.log('GET signature invalid');
    return false;
  }

  return true;
};

const isValidTimestamp = (
  sentAtSeconds,
  receivedAtSeconds,
  leniencyInSeconds = 300
) => {
  return (
    Math.abs(Number(sentAtSeconds) - Number(receivedAtSeconds)) <
    Number(leniencyInSeconds)
  );
};

const getPathForSignatureVerification = (input) => {
  const paths = [
    "/configuration",
    "/configuration/delete",
    "/content/resources/find",
    "/editing/image/process",
    "/editing/image/process/get",
    "/publish/resources/find",
    "/publish/resources/get",
    "/publish/resources/upload",
    "/fav-stats",
    "/logout",
    "/redirect-url",
    "/authentication/check",
  ];

  return paths.find((path) => input.endsWith(path));
};

const calculateSignature = (key, payload) => {
  const hmac = crypto.createHmac("sha256", key);
  hmac.update(payload);
  const signature = hmac.digest("hex");
  return signature;
};