import express from "express";
import { Client } from 'pg';
import { isValidGetRequest, isValidPostRequest } from "./validation";

let client = null;
const connectDb = () => {
  // if (client != null) return client;
  const _client = new Client({
    user: process.env.PGUSER,
    host: process.env.PGHOST,
    database: process.env.PGDATABASE,
    password: process.env.PGPASSWORD,
    port: process.env.PGPORT,
  });
  client = _client;
  return client;
};

export const authentication = () => {
  const app = express();
  app.use(express.json({
      verify: (request, _, buffer) => {
        (request as any).rawBody = buffer.toString();
      },
    })
  );

  /**
   * This endpoint renders a login page. Once the user logs in, they're
   * redirected back to Canva, which completes the authentication flow.
   */
  app.get("/redirect-url", async (req, res) => {
    const isValid = isValidGetRequest(process.env.CLIENT_SECRET, req);
    if (!isValid) {
      res.sendStatus(401);
      return;
    }

    // Get the user's ID from the query parameters
    const { userWpId, userCanvaId, state } = req.query;
    if (!userWpId || !userCanvaId) {
      res.status(404).send('user wp ID or user canva ID not found');
      return;
    }

    const user = await query(`SELECT * FROM canva_users WHERE user_canva_id = '${userCanvaId}' AND user_wp_id = '${userWpId}'`);

    if (!user?.rows[0]) { // if user not found, add them
      await query(
        `INSERT INTO canva_users(user_wp_id, user_canva_id) VALUES(${userWpId}, '${userCanvaId}') RETURNING *`
      );
    }

    // Create query parameters for redirecting back to Canva
    const params = new URLSearchParams({
      success: "true",
      state: state.toString(),
    });

    // Redirect the user back to Canva
    res.redirect(302, `https://canva.com/apps/configured?${params}`);
  });

  /**
   * This endpoint checks if a user is authenticated. An app can use the Fetch capability
   * to send a request to this endpoint.
   *
   * Note: The name of the endpoint is arbitrary. You can call it whatever you want. It
   * just needs to be registered via the Developer Portal.
   */
  app.post("/authentication/check", async (req, res) => {
    const isValid = isValidPostRequest(process.env.CLIENT_SECRET, req);
    if (!isValid) {
      res.sendStatus(401);
      return;
    }

    // Get the user's ID from the request headers
    const userCanvaId = req.header("X-Canva-User-Id");
    const userExists = await query(`SELECT * FROM canva_users WHERE user_canva_id = '${userCanvaId}'`);
    const isAuthenticated = userExists.rows.length > 0;

    // Return the authentication status
    res.send({
      isAuthenticated,
    });
  });

  /**
   * This endpoint is called when a user disconnects an app from their account. The app
   * is expected to de-authenticate the user on its backend, so if the user reconnects the
   * app, they'll need to re-authenticate.
   *
   * Note: The name of the endpoint is *not* configurable.
   */
  app.post("/configuration/delete", async (req, res) => {
    const isValid = isValidPostRequest(process.env.CLIENT_SECRET, req);
    if (!isValid) {
      res.sendStatus(404);
      return;
    }

    // Get the user's ID from the request body
    const { userCanvaId } = req.body;;
    await query(`DELETE FROM canva_users WHERE user_canva_id = '${userCanvaId}'`);

    // Confirm that the user was removed
    res.send({
      type: "SUCCESS",
    });
  });

  return app;
};

/** Connect to database and send a request */
const query = async (query) => {
  const _client = connectDb();
  _client.connect();
  const data = await _client.query(query);
  await _client.end();
  return data;
};