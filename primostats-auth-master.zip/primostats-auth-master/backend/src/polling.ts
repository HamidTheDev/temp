import express from "express";
import { randomUUID } from "crypto";

/**
 * These endpoints demonstrate how a backend can support polling. This lets apps support tasks
 * that exceed the timeout duration.
 *
 * To see how the endpoints are used, see app/src/examples/polling.tsx. You'll need to register
 * the endpoints via the Developer Portal before trying to use them.
 */

// The amount of time it takes for the long-running task to complete
const FAKE_TASK_DURATION_MS = 10000;

export const polling = () => {
  const app = express();
  app.use(express.json());

  /**
   * An object for keeping tracking of long-running tasks. This is only for demonstration
   * purposes. In a production environment, use a database.
   */
  const tasks: Record<string, boolean> = {};

  app.post("/task/create", async (_, res) => {
    // Generate a token for the task
    const token = randomUUID();

    // The task doesn't exist yet
    console.log("Starting a long-running task.");

    // Create the incomplete task
    tasks[token] = false;

    // Complete the task after X seconds
    setTimeout(() => {
      tasks[token] = true;
    }, FAKE_TASK_DURATION_MS);

    res.send({
      token,
    });
  });

  app.post("/task/poll", async (req, res) => {
    // Get the token of a task
    const { token } = req.body;

    // The task doesn't exist
    if (tasks[token] === null) {
      console.log(`Unknown token '${token}' received.`);
      res.status(404).send({
        message: "Unable to find task with the provided token.",
      });
      return;
    }

    // The task is complete
    if (tasks[token]) {
      console.log("The long-running task is complete!");
      res.send({
        message: "The long-running task is complete!",
      });
      return;
    }

    // The task is incomplete
    console.log("The long-running task is ongoing.");
    res.send({
      token,
    });
  });

  return app;
};
