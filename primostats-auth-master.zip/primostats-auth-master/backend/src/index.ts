import express from 'express';
import axios from 'axios';
import { Client } from 'pg';
import { authentication } from "./authentication";
import { polling } from './polling';
import { isValidPostRequest } from './validation';
import { IncomingMessage } from 'http';

const app = express();
app.use(express.json({
	verify: (request: IncomingMessage & { rawBody: string }, _, buffer) => {
		console.log('here', request.url);
		request.rawBody = buffer.toString();
	},
}));
app.use(authentication());
app.use(polling());

const baseUrl = 'https://primostats.com/wp-json/api/v2';
// const baseUrl = 'https://canva-staging.primostats.com/wp-json/api/v2';


let client = null;
const connectDb = () => {
	// if (client != null) return client;
	const _client = new Client({
		user: process.env.PGUSER,
		host: process.env.PGHOST,
		database: process.env.PGDATABASE,
		password: process.env.PGPASSWORD,
		port: process.env.PGPORT,
	});
	client = _client;
	return client;
};

app.post('/fav-stats', async (req, res) => {
	const isValid = isValidPostRequest(process.env.CLIENT_SECRET, req);
	if (!isValid) {
		res.sendStatus(401);
		return;
	}

	const userCanvaId = req.headers['x-canva-user-id'];
	console.log('user canva id', userCanvaId);
	const userResponse = await query(`SELECT * FROM canva_users WHERE user_canva_id = '${userCanvaId}'`);
	const user = userResponse.rows[0];
	console.log('user here', user);
	const response = await axios.get(`${baseUrl}/fav-stats/byUser/${user.user_wp_id}`);
	res.send(response.data);
});

app.post('/logout', async (req, res) => {
	const isValid = isValidPostRequest(process.env.CLIENT_SECRET, req);
	if (!isValid) {
		res.sendStatus(404);
		return;
	}

	const userCanvaId = req.headers['x-canva-user-id'];
	const setUser = await query(
		`DELETE FROM canva_users WHERE user_canva_id = '${userCanvaId}' RETURNING *`
	);
	res.send(setUser.rows[0]);
});

/** Connect to database and send a request */
const query = async (query) => {
	const _client = connectDb();
	_client.connect();
	const data = await _client.query(query);
	await _client.end();
	return data;
};

const port = process.env['CANVA_API_BACKEND_PORT'];
console.log(`Listening on port ${port}`);
app.listen(port);