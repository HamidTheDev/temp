# canva-api-starter-kit-alpha

Welcome to the starter kit! This repo contains a boilerplate for getting an app up and running in a matter of minutes.

## :wrench: Requirements

- Node.js 14.18.1 (or a higher, compatible version)
- Yarn

## :sparkles: Quick start

```bash
git clone git@github.com:canva-sdks/canva-api-starter-kit-alpha.git
cd canva-api-starter-kit-alpha
yarn
yarn --cwd app start
```

For a complete introduction to developing an app, [read the documentation](https://docs.google.com/document/d/1SDZ6mX0i93NUIOhvGyoHWizSzcn_oBSlA0quMxPPwYU).

## :file_folder: Structure

### app/

This directory contains a React and TypeScript-based boilerlpate for getting the frontend of an app up and running. This is where most of the app's code lives, including the code that render's the apps UI and initializes Canva's APIs.

### backend/

This directory contains an Express.js-based boilerplate for getting the backend of an app up and running. You can then use the Fetch API to send requests to the backend.

### sdk/

This directory contains the SDKs that the app depends on, including:

- `@canva/design-interaction`
- `@canva/fetch`
- `@canva/ui`

You don't have to — and in fact, shouldn't — touch the files in this directory.
