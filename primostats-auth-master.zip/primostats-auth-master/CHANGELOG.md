# Changelog
## 2022-06-09

* Added a couple of examples that demonstrate the Fetch API and the `useFetch` hook:
	* `app/src/examples/fetch.tsx`
	* `app/src/examples/fetch_image.tsx`
* Improved the error messages throughout the Design Interaction API.
* Hex codes are now case insensitive. (Previously, only lowercase values were accepted.)
* Fixed the "Use custom width" option in `app/src/examples/app_text_elements.tsx`.
* Update the README in the starter kit.
* Added a [CHANGELOG](https://github.com/canva-sdks/canva-api-starter-kit-alpha/blob/main/CHANGELOG.md) in the starter kit 
