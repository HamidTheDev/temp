<?php
function ps_get_user_by_email(WP_REST_Request $request) {
    $user = get_user_by('email', $request['email']);
    if (!$user) {
        return false;
    }

    return [
        "id" => $user->id,
        "roles" => $user->roles,
    ];
}

function get_user_fav_stats(WP_REST_Request $request) {
    $user_id = $request['userId'];
    // get fav list stats
    $args = array(
        'post_type' => 'fav_list',
        'posts_per_page' => -1,
        'author__in' => $user_id, 
    );
    $fav_list = get_posts($args);

    // Add custom fields to the results
    $fav_stats = $fav_list[0];
    $data = unserialize(get_field('stats', $fav_stats->ID));
    if (!$data) {
        return false;
    }
    $fav_stats_ids = array_keys($data);

    // get stats based on their IDs
    if (count($fav_stats_ids) > 0) {
        $fav_stats = [];
        $query = new WP_Query( array(
            'post__in' => $fav_stats_ids,
            'post_type' => 'stat',
            'meta_key'			=> 'cstm_date_order_user_' . $user_id,
            'orderby'			=> 'meta_value',
            'order'				=> 'DESC',
        ) );
        if ( $query->have_posts() && !empty($fav_stats_ids)) {
						    		   		
            while ($query->have_posts()) {
                $query->the_post();
                $fav_stat_id = get_the_ID();
                $fav_stat = [
                    "id" => $fav_stat_id,
                    "statistic" => get_post_meta($fav_stat_id, 'statistic', true),
                    "year" => get_post_meta($fav_stat_id, 'year', true),
                    "source_url" => get_post_meta($fav_stat_id, 'source', true),
                    "source" => get_the_terms($fav_stat_id, 'source')[0]->name,
                    "publication" => get_the_terms($fav_stat_id, 'publication')[0]->name,
                ];
                $fav_stats[] = $fav_stat;
            }
        }
        return $fav_stats;
    }

    return false;
}

function login_user_app(WP_REST_Request $request) {
    $body = $request->get_json_params();
    $email = $body['email'];
    $password = $body['password'];
    $user = get_user_by('email', $email);
    if ($user && wp_check_password($password, $user->data->user_pass, $user->ID)) {
        return ["status" => 200, "data" => ["id" => $user->ID, "roles" => $user->roles]];
    } else {
        return ["status" => 400];
    }
}
