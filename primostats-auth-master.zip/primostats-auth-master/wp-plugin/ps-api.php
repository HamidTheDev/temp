<?php
/*
Plugin Name: PrimoStats API
Plugin URL: https://primostats.com
Version: 0.1
Author: Amine Akhouad
Author URI: https://github.com/akhouad 
 */
// File Security Check
if (!defined('ABSPATH')) {exit;}
// plugin folder url
if (!defined('BB_PLUGIN_URL')) {
    define('BB_PLUGIN_URL', plugin_dir_url(__FILE__));
}

include_once 'functions.php';

class ps_api {
    public function __construct() {
        $this->custom_api();
    }

    public function custom_api() {
        add_action('rest_api_init', function () {
            register_rest_route('api/v2', '/user/byEmail/(?P<email>\S+)', array(
                'methods' => 'GET',
                'callback' => 'ps_get_user_by_email',
            ));
        });

        add_action('rest_api_init', function () {
            register_rest_route('api/v2', '/fav-stats/byUser/(?P<userId>\S+)', array(
                'methods' => 'GET',
                'callback' => 'get_user_fav_stats',
            ));
        });

        add_action('rest_api_init', function () {
            register_rest_route('api/v2', '/login', array(
                'methods' => 'POST',
                'callback' => 'login_user_app',
            ));
        });
    }
}

// instantiate plugin's class
$GLOBALS['ps_api'] = new ps_api();
